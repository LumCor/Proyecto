﻿namespace ProyectoPumarket
{
    class Productos
    {
        #region Atributos
        /// <summary>
        /// nomreProducto es el nombre correspondiente a cada producto.
        /// categoriaProducto es la categoria de cada producto.
        /// </summary>
        private string nombreProducto;

        /// <summary>
        /// precioProducto es el precio correspondiente a cada producto.
        /// </summary>
        private float precioProducto;

        /// <summary>
        /// categoriaProducto es la categoria por la que se clasifica cada producto.
        /// </summary>
        private sbyte categoríaProducto;

        /// <summary>
        /// existenciasProducto es la cantidad que hay de cada producto.
        /// </summary>
        private int existenciasProducto;
        #endregion

        #region Propiedades
        /// <summary>
        /// Encapsulamiento del atributo string nombreProducto.
        /// </summary>
        public string NombreProducto { get => nombreProducto; set => nombreProducto = value; }

        /// <summary>
        /// Encapsulamiento del atributo float precioProducto.
        /// </summary>
        public float PrecioProducto { get => precioProducto; set => precioProducto = value; }

        /// <summary>
        /// Encapsulamiento del atributo int existenciaProducto.
        /// </summary>
        public int ExistenciasProducto { get => existenciasProducto; set => existenciasProducto = value; }

        /// <summary>
        /// Encapsulamiento del atributo sbyte categoriaProducto.
        /// </summary>
        public sbyte CategoríaProducto { get => categoríaProducto; set => categoríaProducto = value; }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor de la clase Productos.
        /// Para que nuestra ArrayList "inventario" tenga la estructura de productos.
        /// </summary>
        /// <param name="nombreProducto">Atributo correspondiente al nombre.</param>
        /// <param name="precioProducto">Atributo correspondiente al precio.</param>
        /// <param name="existenciasProducto">Atributo correspondiente a la cantidad.</param>
        /// <param name="categoríaProducto">Atributo correspondiente a la categoria.</param>
        public Productos(string nombreProducto, float precioProducto, sbyte existenciasProducto, sbyte categoríaProducto)
        {
            NombreProducto = nombreProducto;
            PrecioProducto = precioProducto;
            ExistenciasProducto = existenciasProducto;
            CategoríaProducto = categoríaProducto;
        }
        #endregion
        
    }
}
