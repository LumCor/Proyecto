﻿using System;
using System.Windows.Forms;

namespace ProyectoPumarket
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Constructor del form1 y es el primero formulario con el que empezara la ejecucion.
        /// </summary>
        #region Constructor
        public Form1()
        {
            InitializeComponent();
        }
        #endregion

        #region Eventos
        /// <summary>
        /// Evento el cual abrira el formulario FormValida. 
        /// Ocurre al presionar el boton "btAdmin".
        /// </summary>
        private void btAdmin_Click(object sender, EventArgs e)
        {
            FormValida validación = new FormValida(this);
            this.Hide();
            validación.Show();
        }
        #endregion

    }
}
