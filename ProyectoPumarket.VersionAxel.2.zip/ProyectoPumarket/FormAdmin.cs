﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ProyectoPumarket
{
    public partial class FormAdmin : Form
    {
        #region Atributos
        /// <summary>
        /// formpadre es un parametro.
        /// </summary>
        Form formpadre;

        /// <summary>
        /// producto es un atributo que probiene de la clase Productos.
        /// </summary>
        private Productos producto;

        /// <summary>
        /// i es el identificador de la sucursal.
        /// </summary>
        int i = 1;

        /// <summary>
        /// j es el identificador de la categoría.
        /// </summary>
        int j = 1;

        /// <summary>
        /// atributo correspondiente de nuestra clase tienda.
        /// </summary>
        Tienda Tienda1 = new Tienda();

        /// <summary>
        /// atributo correspondiente de nuestra clase tienda.
        /// </summary>
        Tienda Tienda2 = new Tienda();

        /// <summary>
        /// atributo correspondiente de nuestra clase tienda.
        /// </summary>
        Tienda Tienda3 = new Tienda();
        #endregion

        /// <summary>
        /// Constructor formAdmin
        /// </summary>
        /// <param name="formpadre">parametro del formAdmin</param>
        #region Constructor
        public FormAdmin(Form formpadre)
        {
            Tienda1.ubicación = "Estadio Olímpico";
            this.formpadre = formpadre;
            InitializeComponent();
            MostrarDisplay(1, Tienda1);
        }
        #endregion

        #region Métodos
        /// <summary>
        /// Metodo el cual mostrara y agregara los productos de la categoria y tienda seleccionada en el Display. 
        /// </summary>
        /// <param name="categoria">Categoria correspondiente a cada producto</param>
        /// <param name="tienda">Atributo proveniente de la clase Tienda</param>
        private void MostrarDisplay(int categoria, Tienda tienda)
        {
            Display.Items.Clear();
            foreach (Productos producto in tienda.inventario)
            {
                if (producto.CategoríaProducto == categoria)
                    Display.Items.Add(producto.NombreProducto);
            }

        }

        /// <summary>
        /// Metodo que identificara la cantidad de productos dependiendo de la categoria y la tienda
        /// </summary>
        /// <param name="categoria">Categoria correspondiente al producto</param>
        /// <param name="tienda">Tienda a la cual se desea aplicar el contador</param>
        /// <returns>Regresara el numero de productos respecto a los parametros mencionados.</returns>
        private int Contador(int categoria, Tienda tienda)
        {
            int contador = 0;
            foreach (Productos producto in tienda.inventario)
            {
                if (producto.CategoríaProducto == categoria)
                    contador += 1;
            }
            return contador;
        }


        /// <summary>
        /// Metodo que identificara la ultima posicion del producto de una cierta categoria en una tienda
        /// </summary>
        /// <param name="tienda">Tienda a la que se le aplicara el metodo</param>
        /// <returns>La posicion del ultimo producto de la categoria seleccionada</returns>
        private int ContadorPosición(Tienda tienda)
        {
            int i = 0;
            if (j == 1)
                i = Contador(1, tienda);
            else if (j == 2)
                i = Contador(1, tienda) + Contador(2, tienda);
            else if (j == 3)
                i = Contador(1, tienda) + Contador(2, tienda) + Contador(3, tienda);
            else
                i = Contador(1, tienda) + Contador(2, tienda) + Contador(3, tienda) + Contador(4, tienda);
            return i;
        }

        /// <summary>
        /// Metodo el cual identificara la primera posicion del producto de una cierta categoria en una tienda
        /// </summary>
        /// <param name="categoria">Categoria deseada</param>
        /// <param name="tienda">Tienda a la que se le aplicara el metodo</param>
        /// <returns>La posicion del primer producto de la categoria y tienda seleccionada</returns>
        private int ContadorPosición(int categoria, Tienda tienda)
        {
            int i = 0;
            if (categoria == 2)
                i = Contador(1, tienda);
            else if (categoria == 3)
                i = Contador(1, tienda) + Contador(2, tienda);
            else
                i = Contador(1, tienda) + Contador(2, tienda) + Contador(3, tienda);
            return i;
        }

        /// <summary>
        /// Metodo el cual hara que ocurra el metodo MostrarDisplay.
        /// Hay que tener en cuenta que el metodo mencionada depende de la categoria y de la tienda correspondiente.
        /// </summary>
        private void MostrarBoxes()
        {
            if (i == 1)
            {
                MostrarDisplay(j, Tienda1);
                lbCantidad.Text = "Productos:" + (Contador(j, Tienda1) - 1).ToString();
            }

            if (i == 2)
            {
                MostrarDisplay(j, Tienda2);
                lbCantidad.Text = "Productos:" + (Contador(j, Tienda2) - 1).ToString();
            }
            if (i == 3)
            {
                MostrarDisplay(j, Tienda3);
                lbCantidad.Text = "Productos:" + (Contador(j, Tienda3) - 1).ToString();
            }
        }

        /// <summary>
        /// Metodo el cual limpiara los cuadros de texto
        /// </summary>
        private void LimpiarBoxes()
        {
            txtNombre.Clear();
            txtExistencias.Clear();
            txtPrecio.Clear();
        }
        #endregion

        #region Eventos
        /// <summary>
        /// Evento con el cual si se cierra el formulario, se vuelva a abrir el formulario pasado (FormValida).
        /// Ocurre cuando se cierra la ventana FormAdmin.
        /// </summary>
        private void FormAdmin_FormClosed(object sender, FormClosedEventArgs e)
        {
            formpadre.Show();
        }
        
        /// <summary>
        /// Evento que mostrara los datos contenidos de nuestro producto en los label correspondientes.
        /// Toma en cuenta que primero se separa por tiendas.
        /// Y despues se clasifica por categorias.
        /// Ocurre al interactuar con el Display.
        /// </summary>
        private void Display_SelectedIndexChanged(object sender, EventArgs e)//agregar try catch
        {         
            if(Display.SelectedIndex==0)
            {
                btGuardar.Visible = true;
                btCambios.Visible = false;
                btEliminar.Visible = false;
            }
            else
            {
                btGuardar.Visible = false;
                btCambios.Visible = true;
                btEliminar.Visible = true;
            }
            switch (i)
            {
                case 1:
                    if(j==1)
                        producto = (Productos)Tienda1.inventario[Display.SelectedIndex];
                    else if(j==2)
                        producto = (Productos)Tienda1.inventario[ContadorPosición(2,Tienda1)+Display.SelectedIndex];
                    else if(j==3)
                        producto = (Productos)Tienda1.inventario[ContadorPosición(3,Tienda1) + Display.SelectedIndex];
                    else if(j==4)
                        producto = (Productos)Tienda1.inventario[ContadorPosición(4,Tienda1) + Display.SelectedIndex];
                    break;
                case 2:
                    if (j == 1)
                        producto = (Productos)Tienda2.inventario[Display.SelectedIndex];
                    else if (j == 2)
                        producto = (Productos)Tienda2.inventario[ContadorPosición(2, Tienda2) + Display.SelectedIndex];
                    else if (j == 3)
                        producto = (Productos)Tienda2.inventario[ContadorPosición(3, Tienda2) + Display.SelectedIndex];
                    else if (j == 4)
                        producto = (Productos)Tienda2.inventario[ContadorPosición(4, Tienda2) + Display.SelectedIndex];
                    break;
                case 3:
                    if (j == 1)
                        producto = (Productos)Tienda3.inventario[Display.SelectedIndex];
                    else if (j == 2)
                        producto = (Productos)Tienda3.inventario[ContadorPosición(2, Tienda3) + Display.SelectedIndex];
                    else if (j == 3)
                        producto = (Productos)Tienda3.inventario[ContadorPosición(3, Tienda3) + Display.SelectedIndex];
                    else if (j == 4)
                        producto = (Productos)Tienda3.inventario[ContadorPosición(4, Tienda3) + Display.SelectedIndex];
                    break;
            }
            txtNombre.Text = producto.NombreProducto;
            txtPrecio.Text = producto.PrecioProducto.ToString();
            txtExistencias.Text = producto.ExistenciasProducto.ToString();
        }
       
        /// <summary>
        /// Evento con el cual se designa la sucursal: Estado Olimpico.
        /// Ocurre cuando se interactua con el Strip Menu
        /// </summary>
        private void estadioOlímpicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            i = 1;
            lbSucursal.Text = "Sucursal: Estadio Olímpico";
        }

        /// <summary>
        /// Evento con el cual se designa la sucursal: Camino Verda.
        /// Ocurre cuando se interactua con el Strip Menu
        /// </summary>
        private void caminoVerdeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            i = 2;
            lbSucursal.Text = "Sucursal: Camino Verde";
        }

        /// <summary>
        /// Evento con el cual se designa la sucursal: Islas.
        /// Ocurre cuando se interactua con el Strip Menu
        /// </summary>
        private void islasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            i = 3;
            lbSucursal.Text = "Sucursal: Islas";
        }

        /// <summary>
        /// Evento con el cual se designa la categoria del producto: Alimentos
        /// Ocurre cuando se interactua con los checkBox
        /// </summary>
        private void btAlimentos_CheckedChanged(object sender, EventArgs e)
        {
            j = 1;
            MostrarBoxes();
            LimpiarBoxes();
        }

        /// <summary>
        /// Evento con el cual se designa la categoria del producto: Papeleria
        /// Ocurre cuando se interactua con los checkBox
        /// </summary>
        private void btFarmacia_CheckedChanged(object sender, EventArgs e)
        {
            j = 2;
            MostrarBoxes();
            LimpiarBoxes();
        }

        /// <summary>
        /// Evento con el cual se designa la categoria del producto: Farmacia
        /// Ocurre cuando se interactua con los checkBox
        /// </summary>
        private void btPapelería_CheckedChanged(object sender, EventArgs e)
        {
            j = 3;
            MostrarBoxes();
            LimpiarBoxes();
        }

        /// <summary>
        /// Evento con el cual se designa la categoria del producto: Boleto de eventos
        /// Ocurre cuando se interactua con los checkBox
        /// </summary>
        private void btBoletos_CheckedChanged(object sender, EventArgs e)
        {
            j = 4;
            MostrarBoxes();
            LimpiarBoxes();
        }

        /// <summary>
        /// Evento que agregara un elemento nuevo a la lista inventario
        /// Ocurre cuento se oprime el boton "Guardar"
        /// </summary>
        private void btGuardar_Click(object sender, EventArgs e) //Cambiar los sbyte.Parse a int
        {
            try
            {
                switch (i)
                {
                    case 1:
                        Tienda1.inventario.Insert(ContadorPosición(Tienda1), new Productos(txtNombre.Text, float.Parse(txtPrecio.Text), sbyte.Parse(txtExistencias.Text), (sbyte)j));
                        MostrarDisplay(j, Tienda1);
                        break;
                    case 2:
                        Tienda2.inventario.Insert(ContadorPosición(Tienda2), new Productos(txtNombre.Text, float.Parse(txtPrecio.Text), sbyte.Parse(txtExistencias.Text), (sbyte)j));
                        MostrarDisplay(j, Tienda2);
                        break;
                    case 3:
                        Tienda3.inventario.Insert(ContadorPosición(Tienda3), new Productos(txtNombre.Text, float.Parse(txtPrecio.Text), sbyte.Parse(txtExistencias.Text), (sbyte)j));
                        MostrarDisplay(j, Tienda3);
                        break;
                }
                txtExistencias.Clear();
                txtNombre.Clear();
                txtPrecio.Clear();
            }

            catch (FormatException)
            {
                MessageBox.Show("Ingrese todos los datos solicitados");
            }

        }
        #endregion
    }
}
