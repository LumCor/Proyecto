﻿using System.Collections;
namespace ProyectoPumarket
{
    class Tienda
    {
        #region Atributos

        /// <summary>
        /// ubicacion corresponde a la localizacion que tendra cada tienda.
        /// </summary>
        public string ubicación;

        /// <summary>
        /// inventario es nuestra ArrayList que contendra todos los productos del sistema.
        /// </summary>
        public ArrayList inventario;
        #endregion

        #region Propiedades
        /// <summary>
        /// Encapsulamiento del atributo string ubicacion.
        /// </summary>
        public string Ubicación { get => ubicación; set => ubicación = value; }
        #endregion

        #region Constructor
        /// <summary>
        /// Funcion con la cual se genero un producto de cada categoria en la ArrayList "inventario" .
        /// </summary>
        public Tienda()
        {
            Ubicación = ubicación;
            inventario = new ArrayList();
            inventario.Add(new Productos("Nuevo producto Alimentos",0,0, 1));
            inventario.Add(new Productos("Nuevo producto Farmacia", 0, 0, 2));
            inventario.Add(new Productos("Nuevo producto Papeleria", 0, 0, 3));
            inventario.Add(new Productos("Nuevo evento", 0, 0, 4));
        }
        #endregion
    }
}
