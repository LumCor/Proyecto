﻿using System;
using System.Windows.Forms;
using System.Collections;
using UsuariosPUMARKET;

namespace ProyectoPumarket
{
    public partial class FormValida : Form
    {
        /// <summary>
        /// usuarios es una ArrayList la cual contendra la informacion de todos los usuarios ingresados
        /// correcto es un bolleano para verificar si nuestras funciones validaUsuario y validaAdmin se cumplan
        /// formpadre es un parametro
        /// </summary>
        #region Atributos
        ArrayList usuarios;
        bool correct = false;
        Form formpadre;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor de FormValida
        /// </summary>
        /// <param name="formpadre">parametro para que el formulario pueda depender del formulario pasado</param>
        public FormValida(Form formpadre)
        {
            this.formpadre = formpadre;
            InitializeComponent();
            usuarios = new ArrayList();
            usuarios.Add(new UsuariosPumarket("Admin","123",true));
            usuarios.Add(new UsuariosPumarket("User", "123", false));
        }
        #endregion

        #region Métodos
        /// <summary>
        /// Funcion que verificara que el nombre y contraseña del usuario esten en el sistema
        /// </summary>
        /// <returns>Boleano "correct"</returns>
        public bool validaUsuario()
        {
            foreach(UsuariosPumarket usuario in usuarios)
            {
                if (txtUser.Text == usuario.NombreUsuario && txtPass.Text == usuario.Password && usuario.Persona==false)
                {
                    correct = true;
                    break;
                }
                else
                    correct = false;
            }
            return correct;
        }

        /// <summary>
        /// Funcion que verificara que el nombre y contraseña del administrador esten en el sistema
        /// </summary>
        /// <returns>>Boleano "correct"</returns>
        public bool validaAdmin()
        {
            foreach (UsuariosPumarket usuario in usuarios)
            {
                if (txtUser.Text == usuario.NombreUsuario && txtPass.Text == usuario.Password && usuario.Persona == true)
                {
                    correct = true;
                    break;
                }
                else
                    correct = false;
            }
            return correct;
        }
        #endregion

        #region Eventos
        /// <summary>
        /// Evento que abrira el formulario FormAdmin siempre y cuando la funcion validaAdmin sea verdadera
        /// Ocurre al presionar el boton "btEntrar"
        /// </summary>
        private void btEntrar_Click(object sender, EventArgs e)
        {

            if (validaAdmin())
            {
                FormAdmin admin = new FormAdmin(this);
                admin.Show();
                this.Hide();
            }
            else
                MessageBox.Show("Usuario y/o contraseña incorrectos");
        }

        /// <summary>
        /// Evento con el cual si se cierra el formulario, se vuelva a abrir el formulario pasado (Form1)
        /// Ocurre si se cierra FormValida
        /// </summary>
        private void FormValida_FormClosed(object sender, FormClosedEventArgs e)
        {
            formpadre.Show();
        }
        #endregion

    }
}
