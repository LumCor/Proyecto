﻿namespace ProyectoPumarket
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.verSucursalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadioOlímpicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.caminoVerdeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.islasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Display = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbCantidad = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtExistencias = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btAlimentos = new System.Windows.Forms.RadioButton();
            this.btBoletos = new System.Windows.Forms.RadioButton();
            this.btPapelería = new System.Windows.Forms.RadioButton();
            this.btFarmacia = new System.Windows.Forms.RadioButton();
            this.btGuardar = new System.Windows.Forms.Button();
            this.btEliminar = new System.Windows.Forms.Button();
            this.lbSucursal = new System.Windows.Forms.Label();
            this.btCambios = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verSucursalesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(782, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // verSucursalesToolStripMenuItem
            // 
            this.verSucursalesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.estadioOlímpicoToolStripMenuItem,
            this.caminoVerdeToolStripMenuItem,
            this.islasToolStripMenuItem});
            this.verSucursalesToolStripMenuItem.Name = "verSucursalesToolStripMenuItem";
            this.verSucursalesToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.verSucursalesToolStripMenuItem.Text = "Ver sucursales";
            // 
            // estadioOlímpicoToolStripMenuItem
            // 
            this.estadioOlímpicoToolStripMenuItem.Name = "estadioOlímpicoToolStripMenuItem";
            this.estadioOlímpicoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.estadioOlímpicoToolStripMenuItem.Text = "Estadio Olímpico";
            this.estadioOlímpicoToolStripMenuItem.Click += new System.EventHandler(this.estadioOlímpicoToolStripMenuItem_Click);
            // 
            // caminoVerdeToolStripMenuItem
            // 
            this.caminoVerdeToolStripMenuItem.Name = "caminoVerdeToolStripMenuItem";
            this.caminoVerdeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.caminoVerdeToolStripMenuItem.Text = "Camino Verde";
            this.caminoVerdeToolStripMenuItem.Click += new System.EventHandler(this.caminoVerdeToolStripMenuItem_Click);
            // 
            // islasToolStripMenuItem
            // 
            this.islasToolStripMenuItem.Name = "islasToolStripMenuItem";
            this.islasToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.islasToolStripMenuItem.Text = "Islas";
            this.islasToolStripMenuItem.Click += new System.EventHandler(this.islasToolStripMenuItem_Click);
            // 
            // Display
            // 
            this.Display.FormattingEnabled = true;
            this.Display.Location = new System.Drawing.Point(35, 61);
            this.Display.Name = "Display";
            this.Display.Size = new System.Drawing.Size(330, 225);
            this.Display.TabIndex = 1;
            this.Display.SelectedIndexChanged += new System.EventHandler(this.Display_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(442, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Categoría:";
            // 
            // lbCantidad
            // 
            this.lbCantidad.AutoSize = true;
            this.lbCantidad.Location = new System.Drawing.Point(113, 309);
            this.lbCantidad.Name = "lbCantidad";
            this.lbCantidad.Size = new System.Drawing.Size(126, 13);
            this.lbCantidad.TabIndex = 6;
            this.lbCantidad.Text = "Cantidad de productos: 0";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(524, 114);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(202, 20);
            this.txtNombre.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(409, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nombre del producto:";
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(524, 155);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(202, 20);
            this.txtPrecio.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(409, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Precio del producto:";
            // 
            // txtExistencias
            // 
            this.txtExistencias.Location = new System.Drawing.Point(524, 193);
            this.txtExistencias.Name = "txtExistencias";
            this.txtExistencias.Size = new System.Drawing.Size(202, 20);
            this.txtExistencias.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(393, 196);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Existencias del producto:";
            // 
            // btAlimentos
            // 
            this.btAlimentos.AutoSize = true;
            this.btAlimentos.Checked = true;
            this.btAlimentos.Location = new System.Drawing.Point(524, 61);
            this.btAlimentos.Name = "btAlimentos";
            this.btAlimentos.Size = new System.Drawing.Size(70, 17);
            this.btAlimentos.TabIndex = 14;
            this.btAlimentos.TabStop = true;
            this.btAlimentos.Text = "Alimentos";
            this.btAlimentos.UseVisualStyleBackColor = true;
            this.btAlimentos.CheckedChanged += new System.EventHandler(this.btAlimentos_CheckedChanged);
            // 
            // btBoletos
            // 
            this.btBoletos.AutoSize = true;
            this.btBoletos.Location = new System.Drawing.Point(615, 84);
            this.btBoletos.Name = "btBoletos";
            this.btBoletos.Size = new System.Drawing.Size(116, 17);
            this.btBoletos.TabIndex = 15;
            this.btBoletos.Text = "Boletos de eventos";
            this.btBoletos.UseVisualStyleBackColor = true;
            this.btBoletos.CheckedChanged += new System.EventHandler(this.btBoletos_CheckedChanged);
            // 
            // btPapelería
            // 
            this.btPapelería.AutoSize = true;
            this.btPapelería.Location = new System.Drawing.Point(524, 84);
            this.btPapelería.Name = "btPapelería";
            this.btPapelería.Size = new System.Drawing.Size(71, 17);
            this.btPapelería.TabIndex = 16;
            this.btPapelería.Text = "Papelería";
            this.btPapelería.UseVisualStyleBackColor = true;
            this.btPapelería.CheckedChanged += new System.EventHandler(this.btPapelería_CheckedChanged);
            // 
            // btFarmacia
            // 
            this.btFarmacia.AutoSize = true;
            this.btFarmacia.Location = new System.Drawing.Point(615, 61);
            this.btFarmacia.Name = "btFarmacia";
            this.btFarmacia.Size = new System.Drawing.Size(68, 17);
            this.btFarmacia.TabIndex = 17;
            this.btFarmacia.Text = "Farmacia";
            this.btFarmacia.UseVisualStyleBackColor = true;
            this.btFarmacia.CheckedChanged += new System.EventHandler(this.btFarmacia_CheckedChanged);
            // 
            // btGuardar
            // 
            this.btGuardar.Location = new System.Drawing.Point(519, 234);
            this.btGuardar.Name = "btGuardar";
            this.btGuardar.Size = new System.Drawing.Size(75, 23);
            this.btGuardar.TabIndex = 18;
            this.btGuardar.Text = "Guardar";
            this.btGuardar.UseVisualStyleBackColor = true;
            this.btGuardar.Visible = false;
            this.btGuardar.Click += new System.EventHandler(this.btGuardar_Click);
            // 
            // btEliminar
            // 
            this.btEliminar.Location = new System.Drawing.Point(615, 234);
            this.btEliminar.Name = "btEliminar";
            this.btEliminar.Size = new System.Drawing.Size(75, 23);
            this.btEliminar.TabIndex = 19;
            this.btEliminar.Text = "Eliminar";
            this.btEliminar.UseVisualStyleBackColor = true;
            this.btEliminar.Visible = false;
            // 
            // lbSucursal
            // 
            this.lbSucursal.AutoSize = true;
            this.lbSucursal.Location = new System.Drawing.Point(310, 34);
            this.lbSucursal.Name = "lbSucursal";
            this.lbSucursal.Size = new System.Drawing.Size(134, 13);
            this.lbSucursal.TabIndex = 20;
            this.lbSucursal.Text = "Sucursal: Estadio Olímpico";
            // 
            // btCambios
            // 
            this.btCambios.Location = new System.Drawing.Point(500, 234);
            this.btCambios.Name = "btCambios";
            this.btCambios.Size = new System.Drawing.Size(109, 23);
            this.btCambios.TabIndex = 21;
            this.btCambios.Text = "Guardar cambios";
            this.btCambios.UseVisualStyleBackColor = true;
            this.btCambios.Visible = false;
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 343);
            this.Controls.Add(this.btCambios);
            this.Controls.Add(this.lbSucursal);
            this.Controls.Add(this.btEliminar);
            this.Controls.Add(this.btGuardar);
            this.Controls.Add(this.btFarmacia);
            this.Controls.Add(this.btPapelería);
            this.Controls.Add(this.btBoletos);
            this.Controls.Add(this.btAlimentos);
            this.Controls.Add(this.txtExistencias);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtPrecio);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbCantidad);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Display);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormAdmin";
            this.Text = "FormAdmin";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormAdmin_FormClosed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem verSucursalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estadioOlímpicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem caminoVerdeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem islasToolStripMenuItem;
        private System.Windows.Forms.ListBox Display;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbCantidad;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtExistencias;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton btAlimentos;
        private System.Windows.Forms.RadioButton btBoletos;
        private System.Windows.Forms.RadioButton btPapelería;
        private System.Windows.Forms.RadioButton btFarmacia;
        private System.Windows.Forms.Button btGuardar;
        private System.Windows.Forms.Button btEliminar;
        private System.Windows.Forms.Label lbSucursal;
        private System.Windows.Forms.Button btCambios;
    }
}